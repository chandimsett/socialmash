<?php
$db_username 	= 'xxxx';
$db_password 	= 'xxxx';
$db_name 		= 'xxxx';
$db_host 		= 'localhost';
$items_per_group = 5;
$mysqli = new mysqli($db_host, $db_username, $db_password,$db_name);
?>